/*Desenvolvido por João Victor Simonassi Farias
para sala de recursos do colégio La Salle Abel
- Estágio em Educação Tecnológica - 2019 . 2
Contato: jsimonassi@id.uff.br
Cel: 21 96675-5666

Objetivo: Auxiliar a escrita de crianças portadoras
de necessidades especiais. O aplicativo será parte
fundamental da nomeada "Máquina de Segredos".
Um aluno deve escrever e outro deve ouvir como em
um telefone sem fio. A escrita incorreta se tornará
evidente para o aluno que está ouvindo e este deve sinalizar
o erro cometido.
 */
package com.example.pintor30;

import androidx.appcompat.app.AppCompatActivity;
import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.google.api.client.extensions.android.json.AndroidJsonFactory;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.services.vision.v1.Vision;
import com.google.api.services.vision.v1.VisionRequestInitializer;
import com.google.api.services.vision.v1.model.AnnotateImageRequest;
import com.google.api.services.vision.v1.model.BatchAnnotateImagesRequest;
import com.google.api.services.vision.v1.model.BatchAnnotateImagesResponse;
import com.google.api.services.vision.v1.model.Feature;
import com.google.api.services.vision.v1.model.Image;
import com.google.api.services.vision.v1.model.TextAnnotation;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private Button btn_limpar;
    private Button btn_falar;
    //private TextView texto;
    private Switch borracha;
    TextToSpeech textToSpeech;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_limpar = findViewById(R.id.btn_clear);
        btn_falar = findViewById(R.id.Id_falar);
        //texto = findViewById(R.id.id_textoLido);
        borracha = findViewById(R.id.id_borracha);

        textToSpeech = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if(status != TextToSpeech.ERROR) {
                    textToSpeech.setLanguage(Locale.getDefault());
                    textToSpeech.setSpeechRate(0.5f);
                    textToSpeech.setPitch(0.8f);
                }
            }
        });


        btn_limpar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainFragment.dv.clearDrawing();
            }
        });

        btn_falar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ConnectivityManager cm = (ConnectivityManager) getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
                NetworkInfo netInfo = cm.getActiveNetworkInfo(); //Preciso alterar


                if ( (netInfo != null) && (netInfo.isConnectedOrConnecting()) && (netInfo.isAvailable()) )
                    new Task(v.getContext()).execute(); //Executa em segundo plano
                else
                    Toast.makeText(getApplicationContext(),"Sem conexão", Toast.LENGTH_LONG).show();
            }
        });

        borracha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(borracha.isChecked()){ //Desliga a borracha
                                        MainFragment.mPaint.setColor(Color.WHITE);
                    MainFragment.mPaint.setStrokeWidth(30);
                }
                else{                    //Liga a borracha
                    MainFragment.mPaint.setColor(Color.DKGRAY);
                    MainFragment.mPaint.setStrokeWidth(6);
                }
            }
        });
    }

    public Bitmap screenShot(View view) {
        Bitmap bitmap = Bitmap.createBitmap(view.getWidth(),
                view.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        view.draw(canvas);
        return bitmap;
    }

    private class Task extends AsyncTask<Void, Void, Void> {

        private ProgressDialog dialog;
        private Context context;

        public Task(Context context) {
            this.context = context;
        }

        @Override
        protected void onPreExecute() {
            dialog = new ProgressDialog(context);
            dialog.setTitle("Carregando");
            dialog.setMessage("Preparando fala...");
            dialog.show();
        }

        @Override
        protected Void doInBackground(Void... params) {

            Vision.Builder visionBuilder = new Vision.Builder(
                    new NetHttpTransport(),
                    new AndroidJsonFactory(),
                    null);

            visionBuilder.setVisionRequestInitializer(
                    new VisionRequestInitializer("AIzaSyCZpVkPHVcj8MrOv1xupA8k1GgVnDuxJLU"));
            final Vision vision = visionBuilder.build();

            Bitmap bitmap = screenShot(MainFragment.dv); //Tira print do fragmento

            ByteArrayOutputStream stream = new ByteArrayOutputStream(); //Passando bitmap para array de bytes
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
            byte[] photoData = stream.toByteArray();
            bitmap.recycle();
            Image inputImage = new Image();
            inputImage.encodeContent(photoData);

            Feature desiredFeature = new Feature();
            desiredFeature.setType("TEXT_DETECTION");
            AnnotateImageRequest request = new AnnotateImageRequest();
            request.setImage(inputImage);
            request.setFeatures(Arrays.asList(desiredFeature));
            BatchAnnotateImagesRequest batchRequest = new BatchAnnotateImagesRequest();
            batchRequest.setRequests(Arrays.asList(request));

            try {
                BatchAnnotateImagesResponse batchResponse = vision.images().annotate(batchRequest).execute();
                final TextAnnotation text = batchResponse.getResponses().get(0).getFullTextAnnotation();
                dialog.dismiss();
                if (text != null) {
                    textToSpeech.speak(text.getText(), TextToSpeech.QUEUE_FLUSH, null);
                }else {
                    Toast.makeText(getApplicationContext(), "Sem retorno da API. Null.", Toast.LENGTH_LONG).show();
                }
            } catch (IOException e) {
                Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                e.printStackTrace();
            }

            return null;
        }
    }
}